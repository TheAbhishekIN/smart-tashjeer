<a href="/">
    <img src="{{asset('assets/logo.png')}}" class="block w-auto" alt="">
</a>
