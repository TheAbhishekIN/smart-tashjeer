<a href="/">
    <img src="<?php echo e(asset('assets/logo.png')); ?>" class="block w-auto" alt="">
</a>
<?php /**PATH /home/abhi/abhi/smart-tashjeer/resources/views/components/authentication-card-logo.blade.php ENDPATH**/ ?>