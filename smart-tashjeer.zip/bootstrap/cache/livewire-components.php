<?php return array (
  'news.create-edit' => 'App\\Http\\Livewire\\News\\CreateEdit',
  'pages.create-edit' => 'App\\Http\\Livewire\\Pages\\CreateEdit',
  'posts.view' => 'App\\Http\\Livewire\\Posts\\View',
  'user.index' => 'App\\Http\\Livewire\\User\\Index',
  'user.user-detail' => 'App\\Http\\Livewire\\User\\UserDetail',
);